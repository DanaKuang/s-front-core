## 页面开发笔记
    Create Date: 2017-07-10
    Author: liubin
    Description: kpi模块描述
## 开发模块
    KPI                          ## 模块名称 
    KPICtrl                      ## 控制器名称
    kpiViewModel                 ## 视图模版
    kpi                          ## 页面文件
## 后端接口说明
    
## 问题及解决办法
    1) xx
    2) xx
    ...
## MOERE
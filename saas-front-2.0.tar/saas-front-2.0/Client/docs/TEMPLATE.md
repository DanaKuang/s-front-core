## 页面开发笔记
    Create Date: {20xx-xx-xx}
    Author: {author}
    Description: {xx}
## 开发模块
    KPI                          ## 模块名称 
    KPICtrl                      ## 控制器名称
    kpiViewModel                 ## 视图模版
    kpi                          ## 页面文件
## 后端接口说明
    
## 问题及解决办法
    1) xx
    2) xx
    ...
## MOERE

/**
 * Author: liubin
 * Create Date: 2017-06-27
 * Description: index
 */

define([], function() {
    var MainCtrl = {
        ServiceType: "controller",
        ServiceName: "MainCtrl",
        ViewModelName: 'mainViewModel',
        ServiceContent: ['$scope', 'mainViewModel', 'menuFilter', function($scope, $model, menuFilter) {

            // 获取数据
            $model.getNav().then(function(res) {
                var data = res.data || {};
                $scope.navConf = {
                    nav: menuFilter.nav(data.data),
                    account: sessionStorage.account || ""
                };
            });

            // 获取menu
            $scope.$on('navchangeready', function(e, v) {
                $model.getMenu({
                    parentCode: v.menuCode || "index"
                }).then(function(res) {
                    var menu = res.data.data || [];
                    $(".ui-navbar-left").html(menuFilter.menu(menu)).children().metisMenu();
                });
            });
        }]
    };

  return MainCtrl;
});
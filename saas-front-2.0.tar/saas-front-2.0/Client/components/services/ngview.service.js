/**
 * Author: liubin
 * Create Date: 2017-08-22
 * Description: ng-view
 */

define([], function () {
    var ngViewFactory = {
        ServiceType: "directive",
        ServiceName: "ngView",
        ServiceContent: ['$location', '$route', '$animate', function($location, $route, $animate) {
            var definedObj = {
                restrict: 'ECA',
                terminal: true,
                priority: 400,
                transclude: 'element',
                link: linkFn
            };

            function linkFn (scope, ele, attr, ctrl, $transclude) {
                var currentScope,
                    currentElement,
                    previousElement;

                scope.$on('$routeChangeSuccess', update);
                update();

                function cleanupLastView() {
                    if (previousElement) {
                        previousElement.remove();
                        previousElement = null;
                    }
                    if (currentScope) {
                        currentScope.$destroy();
                        currentScope = null;
                    }
                    if (currentElement) {
                        $animate.leave(currentElement, function() {
                            previousElement = null;
                        });
                        previousElement = currentElement;
                        currentElement = null;
                    }
                }

                function update() {
                    var locals = $route.current && $route.current.locals,
                        template = locals && locals.$template;

                    if (angular.isDefined(template)) {
                        var newScope = scope.$new();
                        var current = $route.current;
                        var clone = $transclude(newScope, function(clone) {
                            $animate.enter(clone, null, currentElement || ele);
                            cleanupLastView();
                        });
                        currentElement = clone;
                        currentScope = current.scope = newScope;
                        currentScope.$emit('$viewContentLoaded');
                    } else {
                        cleanupLastView();
                    }
                }
            }

            return definedObj;
        }]
    };

    /**
     * ngView指令：填充请求结果到页面容器
     * @type {Object}
     */
    var ngViewFillContentFactory = {
        ServiceType: "directive",
        ServiceName: "ngView",
        ServiceContent: ['$compile', '$controller', '$route', '$q', function($compile, $controller, $route, $q) {
            var definedObj = {
                restrict: 'ECA',
                priority: -400,
                link: linkFn
            };

            function linkFn (scope, $element) {
                var current = $route.current;
                var locals = current.locals;
                var _model = {};
                var cm, mm, invokeQueue;

                $element.html(locals.$template);

                var _controller = $(locals.$template).last().attr('ng-controller');
                // 异步加载
                $q.when(function () {
                    cm = angular.module('tztx.saas.cm');
                    mm = angular.module('tztx.saas.mm');
                    invokeQueue = _.unzip(_.last(_.unzip(cm._invokeQueue)));
                }).then(function (promises) {
                    return $q.all(promises());
                }).then(function () {
                    var defer = $q.defer();
                    // 模块文件不会被加载两次
                    if (_.indexOf(_.first(invokeQueue), _controller) === -1) {
                        var path = _controller.replace(/\./g,'\/');
                        require([
                            path + '.controller.js',
                            path + '.model.js'
                        ], function (ctrl, model) {
                            ctrl.ServiceContent.$model = model.ServiceName;
                            cm.controller(ctrl.ServiceName, ctrl.ServiceContent);
                            mm.service(model.ServiceName, model.ServiceContent);
                            // 注册
                            cm.registerController(ctrl.ServiceName, ctrl.ServiceContent);
                            defer.resolve();
                        });
                    } else {
                        defer.resolve();
                    }
                    return defer.promise;
                }).then(function () {
                    cm = angular.module('tztx.saas.cm');
                    invokeQueue = _.unzip(_.last(_.unzip(cm._invokeQueue)));
                    var modelName = _.last(invokeQueue)[_.indexOf(_.first(invokeQueue), _controller)].$model;
                    var mm_r = angular.injector(['tztx.saas.mm']);
                    $route.current.controller = _controller;
                    if (mm_r.has(modelName)) {
                        _model = mm_r.get(modelName);
                        if (_model.$model)
                            _model = new _model.$model();
                    }
                    // 过滤首次进入需要调的接口
                    return _.extend(_model, _.pick(_model, _.filter(_.keys(_model), function(key) {
                        return /^\$/g.test(key);
                    })));
                }).then(function(locals) {
                    if (current.controller) {
                        locals.$scope = scope;
                        locals.$scope.$model = locals;
                    }
                    $compile($element.contents())(scope);
                    //ngView和ngController执行完成，触发事件通知
                    scope.$broadcast('$ExcuteControllerFinished');
                }, function(error) {
                    console.log('$routeChangeError=>', error);
                });
            }
            return definedObj;
        }]
    };
    return [ngViewFactory, ngViewFillContentFactory];
});

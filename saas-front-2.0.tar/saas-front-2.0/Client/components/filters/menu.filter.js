/**
 * Author: liubin
 * Create Date: 2017-07-20
 * Description: 菜单格式化
 */
define([], function () {
    var menuFilter = {
        ServiceType: "factory",
        ServiceName: "menuFilter",
        ServiceContent: ['$filter', function ($filter) {
            function nav (data) {
                data = data || [];
                return _.groupBy(data, 'parentCode')['0'];
            }
            // 菜单
            function menu (data) {
                data = data || [];
                var $result = '<ul class="metismenu">';
                _.each(data, function (d) {
                    var menu = d.menu || {};
                    var node = d.nodeList || [];
                    if (menu) {
                        $result += '<li class="parent">';
                        $result += '<a data-target="'+menu.menuCode+'" data-hash="'+menu.manuUrl+'" href="'+menu.manuUrl+'">';
                        $result += '<span class="fa fa-'+menu.menuCode+'"></span>';
                        $result += '<div class="ellipsis">'+menu.menuName+'</div>';
                        $result += '<span class="fa arrow"></span>';
                        _.each(node, function (n) {
                            $result += '<ul>';
                            $result += '<li class="child">';
                            $result += '<a data-target="'+n.menuCode+'" data-hash="'+n.manuUrl+'" href="'+menu.manuUrl+'">';
                            $result += '<span class="fa fa-'+n.menuCode+'"></span>';
                            $result += '<div class="ellipsis">'+n.menuName+'</div>';
                            $result += '<span class="fa arrow"></span>';
                            $result += '</a>';
                            $result += '</li>';
                            $result += '</ul>';
                        });
                        $result += '</a>';
                        $result += '</li>';
                    }
                });
                $result += '</ul>';
                return $result;
            }
            return angular.extend({
                __filter__: $filter,
                nav: nav,
                menu: menu
            });
        }]
    }
    return [menuFilter];
});
/**
 * Author: liubin
 * Create Date: 2017-08-18
 * Description: app
 */

require([
    "controllers/_controller.min.js",
    "directives/_directives.min.js",
    "templates/_templates.min.js",
    "services/_services.min.js",
    "filters/_filters.min.js",
    "models/_model.min.js"
], function (controller, directive, template, service, filter, model) {
    console.log('************* saas project loading... *************');

    /**
     * dm _directives.min
     * tm _templates.min
     * sm _services.min
     * fm _filters.min
     * cm _controller.min
     * mm _model.min
     */
    var app = angular.module('tztx.saas', [
        'tztx.saas.sm',
        'tztx.saas.dm',
        'tztx.saas.tm',
        'tztx.saas.fm',
        'tztx.saas.cm',
        'tztx.saas.mm'
    ]);

    // 配置初始化入口
    app.run(['$dynamicRoute', 'menuService', function($dynamicRoute, menuService) {
        menuService.animation();
    }]);

    // 启动app，检查授权
    angular.injector(['tztx.saas.sm']).get('authorization').done();
});
## 页面开发流程
    Create Date: 2017-08-18
    Author: liubin
    Description: SAAS平台2.0开发流程及常见问题
## 入口文件
    main.js                      ## node main.js 
## 主要目录结构：
    ## apps                      ## app存放目录
    ## assets                    ## 静态资源image和header、footer模版
    ## components                ## 模版文件，指令编写所需要的模版文件
        ## controllers           ## 控制器模块存放
        ## directives            ## 通用指令存放
        ## filters               ## 通用过滤器
        ## models                ## 数据模型模块存放
        ## services              ## 服务
        ## templates             ## 模版文件存放
    ## config                    ## 配置文件
    ## datas                     ## 静态资源Json文件
    ## docs                      ## 笔记
## 单个重要文件
    * config/config.view.yml     ## 前端所有的视图请求需要在此注册配置
    * config/config.api.yml      ## 前端所有的API请求需要在此注册配置
    * components/app.js          ## 核心模块加载
    * assets/libs/index.js       ## requirejs配置文件AMD规范，异步非阻塞加载
## 开发流程
    1）首先在apps中添加模块文件，如：*.html、*.js。并在html中添加ng-controller控制器；
    2）在config/config.view.yml中注册页面路由及静态物理地址；
    3）在controller文件夹中创建控制器文件，如：kpi.controller.js；   **注意四个属性**
    4）在model文件夹中创建模型文件，如：kpi.model.js；               **注意三个属性**
    5）api调用需在config/config.api.yml文件中注册。
## 潜规则
    1）apps下所有的ServiceName，需要包含路径信息，如：home.kpi.kpi
    2）页面文件，包含ng-controller属性的dom节点需在并列节点的last位置
## 常见问题
    1）view和api未在config中注册；
    2）view中未添加ng-controller或者名称不对应；
## 环境搭建
    1. node环境搭建
        1）官网下载node安装包linux；
        2）解压安装包：`tar -xvf node-**.tar.gz`；
        3）创建软连接：`ln -s /usr/local/src/node**/bin/node /usr/local/bin/node`
                     `ln -s /usr/local/src/node**/bin/npm /usr/local/bin/npm`；
        4）测试：`node -v & npm -v`。
    2. bower环境搭建
        1）bower安装：`npm install bower -g`；
        2）测试：`bower -v`。
    3. 查看node进程
        ps aux | grep node | grep -v grep
    4. 杀死node进程
        kill -9 [pid]       ## 暴力删除，可能会引起进程占用内存不能够被释放
## 代码部署
    1）首先代码可以在本地环境跑起来，保证没有问题；
    2）修改config.yml文件，选择发布点，只需修改def下runmode属性[local,test,dev]；
    3）将代码打包成zip文件，指令：`node main build`；
    4）将代码上传到服务器命令：`scp ./**.zip root@000.00.00.000:/root`；
    5）在服务器上解压文件包，命令：`unzip -o ./sass-front.zip`；
    6）如果之前node已经跑起来，记得kill掉：`kill -9 [pid]`；
    7）cd到项目Client目录下执行命令：`nohup node main.js default >/dev/null 2>&1 &`，回车。
    注：3)至7)步已简化为一行命令：node main publish [161/172/173/174]
## 期望
    1）运行和维护平台的开发人员，每编写一个模块，需有对应的文档解释说明，方便其他人理解上手；
    2）代码规范，严格要求自己，养成好的编码风格和习惯；
## 关于核心模块
    核心模块就在首屏时加载而且只加载一次，指令要可复用性强，又臭又长的代码不适合编写核心模块；
    组件化，需要代码简介，复用性强。
## 回顾
    SAAS平台1.0：解决简单的前后调试跨域问题，使用node做了一层转发；
    SAAS平台1.0-1.5：细节完善，假如一些指令，减少开发人员工作量；
    SAAS平台2.0：将每个模块抽象出来，解决首屏加载缓慢问题，每个模块只加载一次，并做向下兼容；
## 下一步计划
    1）引入karma测试。我觉得创业公司执行不起来，原因很简单，创业公司只关注业务；
    2）ng1到ng2平滑升级。创业公司只关注业务，这也是为什么我在平台2.0并没有使用ng2.0的原因；
    3）2017-8-15，蚂蚁金服开发了ant-design的Angular版本，可以引入进来；
    注：两年做三件事，够了吧，前端市场变化很快，我也不清楚两年后的前端市场是一个什么状况。







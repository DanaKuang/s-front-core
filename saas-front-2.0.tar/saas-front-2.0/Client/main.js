/**
 * Author: liubin
 * Create Date: 2017-06-21
 * Description: 前端入口
 */

require('../Server').start();
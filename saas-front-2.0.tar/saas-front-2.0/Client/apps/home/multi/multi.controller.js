/**
 * Author: liubin
 * Create Date: 2017-07-04
 * Description: multi
 */

define([], function () {
    var multiController = {
        ServiceType: 'controller',
        ServiceName: 'home.multi.multi',
        ViewModelName: 'home.multi.multi',
        ServiceContent: ['$scope', function ($scope) {
            console.log('multi')
        }]
    };

    return multiController;
});
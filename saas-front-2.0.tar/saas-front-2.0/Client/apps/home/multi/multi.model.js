/**
 * Author: liubin
 * Create Date: 2017-07-04
 * Description: multi
 */

define([], function () {
  var multiModel = {
    ServiceType: 'service',
    ServiceName: 'home.multi.multi',
    ServiceContent: ['request', function (request) {
      this.$model = function () {

      };
    }]
  };

  return multiModel;
});
/**
 * Author: liubin
 * Create Date: 2017-08-23
 * Description: kpi controller
 */
define([], function () {
    'use strict';
    return {
        ServiceType: "controller",
        ServiceName: "home.kpi.kpi",
        ViewModelName: 'home.kpi.kpi',
        ServiceContent: ['$scope', function ($scope) {
            console.log('kpi controller loading...');
        }]
    };
});
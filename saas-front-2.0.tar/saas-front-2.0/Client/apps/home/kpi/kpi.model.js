/**
 * Author: liubin
 * Create Date: 2017-08-23
 * Description: kpi model
 */

define([], function () {
    'use strict';
    return {
        ServiceType: "service",
        ServiceName: "home.kpi.kpi",
        ServiceContent: ['request', function (request) {
            this.$model = function () {
                console.log('kpi model loading...');
                var CHINA_JSON_URL = '/statics/home/kpi/china.json';           // 地图JSON
                var ECHART_JSON_CONF = '/statics/home/kpi/echartConf.json';    // echart配置

                this.$chinaJson = request.$Query(CHINA_JSON_URL);
                this.$echartConf = request.$Query(ECHART_JSON_CONF);
            };
        }]
    };
});
/**
 * Author: liubin
 * Create Date: 2017-08-28
 * Description: 一键打包
 */
/**
 * [exports description]
 * @return {[type]} [description]
 */
module.exports = function (callback) {
    'use strict';
    var Q = require('q');
    var del = require('del');
    var gulp = require('gulp');
    var path = require('path');
    var zip = require('gulp-zip');
    var rjs = require('gulp-requirejs');
    var uglify = require('gulp-uglify');
    var concat = require('gulp-concat');
    var header = require('gulp-header');
    var footer = require('gulp-footer');
    var rename = require('gulp-rename');
    var colors = require('colors/safe');
    var dateFormat = require('dateformat');
    var imagemin = require('gulp-imagemin');
    var minifyCss = require('gulp-minify-css');
    var pngquant = require('imagemin-pngquant');
    var minifyJson = require('gulp-jsonminify');
    var minifyHtml = require('gulp-minify-html');
    var zipfile = 'data-front-' + dateFormat(new Date(), "yyyy-mm-dd-HH-MM-ss") + '.zip';

    // 第一步 删除目标文件夹
    var firstStep = function () {
        var deferred = Q.defer();
        process.stdout.write(colors.green('01): del -> \n'));
        process.stdout.write(colors.blue('\x20\x20\x20 del dist\n'));
        del(['dist'], {force: true}, function (error, stdout, stderr) {
            process.stdout.write(colors.blue('\x20\x20\x20 del dist successfully!\n'));
            deferred.resolve(true);
        });
        return deferred.promise;
    };

    // 第二步 复制要压缩的项目
    var secondStep = function () {
        var deferred = Q.defer();
        process.stdout.write(colors.green('02): copy -> \n'));
        process.stdout.write(colors.blue('\x20\x20\x20 copy !doc/*\n'));
        process.stdout.write(colors.blue('\x20\x20\x20 copy !logs/*\n'));
        process.stdout.write(colors.blue('\x20\x20\x20 copy !apps/**/*.spec.js\n'));
        process.stdout.write(colors.blue('\x20\x20\x20 copy !bower_components/*\n'));
        gulp.src([
            './**',
            '!doc/**/*',
            '!logs/**/*',
            '!apps/**/*.spec.js',
            '!bower_components/**/*'
        ])
        .pipe(gulp.dest('dist/data-front/Client'))
        .on('finish', function () {
            process.stdout.write(colors.blue('\x20\x20\x20 copy project successfully!\n'));
            deferred.resolve(true);
        }).on('error', function (error) {
            process.stdout.write(colors.red('\x20\x20\x20 copy project field!\n'));
            deferred.reject(new Error(error));
        });
        return deferred.promise;
    };


    // 第三步 将html模版文件压缩转化成js
    var thirdStep = function () {
        var deferred = Q.defer();
        process.stdout.write(colors.green('03): templates -> \n'));
        process.stdout.write(colors.blue('\x20\x20\x20 minify template html \n'));
        gulp.src('dist/data-front/Client/components/templates/**.tpl.html')
            .pipe(minifyHtml({
                empty: true,
                spare: true,
                quotes: true
            }))
            .pipe(ngHtml2Js({
                moduleName: "ngui.templates",
                template: "$templateCache.put('<%= template.url %>','<%= template.escapedContent %>');"
            }))
            .pipe(gulp.dest('dist/data-front/Client/components/templates'))
            .on('finish', function () {
                process.stdout.write(colors.blue('\x20\x20\x20 minify template html successfully!\n'));
                deferred.resolve(true);
            })
            .on('error', function () {
                process.stdout.write(colors.red('\x20\x20\x20 minify template html field!\n'));
                deferred.reject(new Error(error));
            });
        return deferred.promise;
    };

    // 第四步 合并和压缩模版脚步文件
    var forthStep = function () {
        var deferred = Q.defer();
        process.stdout.write(colors.blue('\x20\x20\x20 minify template js \n'));
        gulp.src([
            '!dist/data-front/Client/components/templates/_templates.min.js',
            'dist/data-front/Client/components/templates/**.js'
        ])
        .pipe(concat('ngui.templates.js'))
        .pipe(gulp.dest('dist/data-front/Client/components/templates'))
        .on('finish', function() {
            process.stdout.write(colors.blue('\x20\x20\x20 minify template js successfully!\n'));
            deferred.resolve(true);
        })
        .on('error', function(error) {
            process.stdout.write(colors.red('\x20\x20\x20 minify template js field!\n'));
            deferred.reject(new Error(error));
        });
        return deferred.promise;
    };

    // 第五步 给ngui.templates.directive.js文件添加头尾
    var fifthStep = function () {
        var deferred = Q.defer();
        process.stdout.write(colors.blue('\x20\x20\x20 minify template html \n'));
        gulp.src('dist/data-front/Client/components/templates/ngui.templates.js')
            .pipe(header("define([], function() {\n" +
                "   'use strict';\n" +
                "   var templates = angular.module('ngui.templates', []);\n" +
                "   templates.run(['$templateCache', function($templateCache) {\n"
            ))
            .pipe(footer("  }]);\n" +
                "   return templates;\n" +
                "});\n"
            ))
            .pipe(gulp.dest('dist/data-front/Client/components/templates'))
            .on('finish', function() {
                del([
                    'dist/data-front/Client/components/templates/*.tpl.html'
                ], function() {
                    process.stdout.write(colors.blue('\x20\x20\x20 minify template successfully! \n'));
                    deferred.resolve(true);
                });
            })
            .on('error', function(error) {
                process.stdout.write(colors.blue('\x20\x20\x20 minify template html field!\n'));
                deferred.reject(new Error(error));
            });
        return deferred.promise;
    };

    // 第六步 压缩componments目录文件
    var sixthStep = function () {
        var deferred = Q.defer();
        process.stdout.write(colors.green('04): componments -> \n'));
        rjs({
            baseUrl: process.cwd() + '/dist/data-front/Client/componments',
            name: "app",
            out: "app.min.js"
        }).pipe(uglify())
        .pipe(gulp.dest(process.cwd() + '/dist/data-front/Client/componments'));
        process.stdout.write(colors.blue('\x20\x20\x20 uglify app successfully!\n'));
        return true;
    };

    // 第七步 删除app下的脚步文件,重命名app.min
    var seventhStep = function () {
        var deferred = Q.defer();
        process.stdout.write(colors.blue('\x20\x20\x20 del !app.min, app/* \n'));
        del([
            'dist/data-front/Client/componments/controllers',
            'dist/data-front/Client/componments/directives',
            'dist/data-front/Client/componments/templates',
            'dist/data-front/Client/componments/services',
            'dist/data-front/Client/componments/filters',
            'dist/data-front/Client/componments/models',
            'dist/data-front/Client/componments/app.js'
        ], {force: true}, function (error, stdout, stderr) {
            gulp.src('dist/data-front/Client/componments/app.min.js')
                .pipe(rename('app.js'))
                .pipe(gulp.dest('dist/data-front/Client/componments'))
                .on('finish', function () {
                    process.stdout.write(colors.blue('\x20\x20\x20 del componments/* successfully!\n'));
                    del(['dist/data-front/Client/componments/app.min.js'], {force: true}, function (error, stdout, stderr) {
                        process.stdout.write(colors.blue('\x20\x20\x20 del app.min successfully!\n'));
                        deferred.resolve(true);
                    });
                }).on('error', function (error) {
                    process.stdout.write(colors.red('\x20\x20\x20 del componments/* field!\n'));
                    deferred.reject(new Error(error));
                });
        });
        return deferred.promise;
    };

    // 第八步 将apps下的html压缩
    var eighthStep = function () {
        var deferred = Q.defer();
        process.stdout.write(colors.green('05): apps -> html \n'));
        process.stdout.write(colors.blue('\x20\x20\x20 minify apps html/js \n'));
        gulp.src('dist/data-front/Client/apps/**/**.html')
            .pipe(minifyHtml({
                empty: true,
                spare: true,
                quotes: true
            }))
            .pipe(gulp.dest('dist/data-front/Client/apps/'))
            .on('finish', function () {
                process.stdout.write(colors.blue('\x20\x20\x20 minify apps html successfully!\n'));
                deferred.resolve(true);
            })
            .on('error', function () {
                process.stdout.write(colors.red('\x20\x20\x20 minify apps html field!\n'));
                deferred.reject(new Error(error));
            });
        return deferred.promise;
    };

    // 第九步 将apps下的js压缩
    var ninthStep = function () {
        var deferred = Q.defer();
        process.stdout.write(colors.green('06): apps -> js \n'));
        process.stdout.write(colors.blue('\x20\x20\x20 minify apps js \n'));
        gulp.src('dist/data-front/Client/apps/**/**.js')
            .pipe(uglify())
            .pipe(gulp.dest('dist/data-front/Client/apps/'))
            .on('finish', function () {
                process.stdout.write(colors.blue('\x20\x20\x20 minify apps js successfully!\n'));
                deferred.resolve(true);
            })
            .on('error', function () {
                process.stdout.write(colors.red('\x20\x20\x20 minify apps js field!\n'));
                deferred.reject(new Error(error));
            });
        return deferred.promise;
    };

    // 第十步 将data下的json压缩
    var tenthStep = function () {
        var deferred = Q.defer();
        process.stdout.write(colors.green('07)：data -> \n'));
        process.stdout.write(colors.blue('\x20\x20\x20 minify data json \n'));
        gulp.src('dist/data-front/Client/datas/**/**.json')
            .pipe(minifyJson())
            .pipe(gulp.dest('dist/data-front/Client/datas/'))
            .on('finish', function () {
                process.stdout.write(colors.blue('\x20\x20\x20 minify json successfully!\n'));
                deferred.resolve(true);
            })
            .on('error', function () {
                process.stdout.write(colors.red('\x20\x20\x20 minify json field!\n'));
                deferred.reject(new Error(error));
            });
        return deferred.promise;
    };

    // 第十一步 压缩图片
    var eleventhStep = function () {
        var deferred = Q.defer();
        process.stdout.write(colors.green('08)：images -> \n'));
        process.stdout.write(colors.blue('\x20\x20\x20 minify images \n'));
        gulp.src('dist/data-front/Client/assets/images/*.{png,jpg,gif,ico}')
            .pipe(imagemin({
                optimizationLevel: 7,   //类型：Number  默认：3  取值范围：0-7（优化等级）
                progressive: true,      //类型：Boolean 默认：false 无损压缩jpg图片
                interlaced: true,       //类型：Boolean 默认：false 隔行扫描gif进行渲染
                multipass: true,        //类型：Boolean 默认：false 多次优化svg直到完全优化
                svgoPlugins: [{
                    removeViewBox: false
                }],                     //不要移除svg的viewbox属性
                use: [pngquant()]       //使用pngquant深度压缩png图片的imagemin插件
            }))
            .pipe(gulp.dest('dist/data-front/Client/assets/images'))
            .on('finish', function () {
                process.stdout.write(colors.blue('\x20\x20\x20 minify images successfully!\n'));
                deferred.resolve(true);
            })
            .on('error', function () {
                process.stdout.write(colors.red('\x20\x20\x20 minify images field!\n'));
                deferred.reject(new Error(error));
            });
        return deferred.promise;
    };

    // 第十二步 压缩css样式文件
    var twelvethStep = function () {
        var deferred = Q.defer();
        process.stdout.write(colors.green('09)：css -> \n'));
        process.stdout.write(colors.blue('\x20\x20\x20 minify css \n'));
        gulp.src('dist/data-front/Client/assets/styles/*.css')
            .pipe(minifyCss({
                advanced: true,           //类型：Boolean 默认：true [是否开启高级优化（合并选择器等）]
                compatibility: 'ie8',     //保留ie7及以下兼容写法 类型：String 默认：''or'*' [启用兼容模式； 'ie7'：IE7兼容模式，'ie8'：IE8兼容模式，'*'：IE9+兼容模式]
                keepBreaks: false,        //类型：Boolean 默认：false [是否保留换行]
                keepSpecialComments: '*'  //保留所有特殊前缀 当你用autoprefixer生成的浏览器前缀，如果不加这个参数，有可能将会删除你的部分前缀
            }))
            .pipe(gulp.dest('dist/data-front/Client/assets/styles'))
            .on('finish', function () {
                process.stdout.write(colors.blue('\x20\x20\x20 minify css successfully!\n'));
                deferred.resolve(true);
            })
            .on('error', function () {
                process.stdout.write(colors.red('\x20\x20\x20 minify css field!\n'));
                deferred.reject(new Error(error));
            });
        return deferred.promise;
    };

    // 第十三步 处理libs下的js文件
    var thirteenthStep = function () {
        var deferred = Q.defer();
        process.stdout.write(colors.green('10)：libs -> \n'));
        process.stdout.write(colors.blue('\x20\x20\x20 minify libs \n'));
        gulp.src('dist/data-front/Client/assets/libs/*.js')
            .pipe(uglify())
            .pipe(gulp.dest('dist/data-front/Client/assets/libs'))
            .on('finish', function () {
                process.stdout.write(colors.blue('\x20\x20\x20 minify libs successfully!\n'));
                deferred.resolve(true);
            })
            .on('error', function () {
                process.stdout.write(colors.red('\x20\x20\x20 minify libs field!\n'));
                deferred.reject(new Error(error));
            });
        return deferred.promise;
    };

    // 第十四步 处理登录/首页 html
    var forteenthStep = function () {
        var deferred = Q.defer();
        process.stdout.write(colors.green('11)：login/index -> \n'));
        process.stdout.write(colors.blue('\x20\x20\x20 minify login/index html \n'));
        // index 压缩后 include问题，暂时未解决
        gulp.src(['dist/data-front/Client/*.html', '!dist/data-front/Client/index.html'])
            .pipe(minifyHtml({
                empty: true,
                spare: true,
                quotes: true
            }))
            .pipe(gulp.dest('dist/data-front/Client'))
            .on('finish', function () {
                process.stdout.write(colors.blue('\x20\x20\x20 minify login/index html successfully!\n'));
                deferred.resolve(true);
            })
            .on('error', function () {
                process.stdout.write(colors.red('\x20\x20\x20 minify login/index html field!\n'));
                deferred.reject(new Error(error));
            });
        return deferred.promise;
    };

    // 第十五步 拷贝Server
    var fifteenthStep = function () {
        var deferred = Q.defer();
        process.stdout.write(colors.green('12)：Server -> \n'));
        process.stdout.write(colors.blue('\x20\x20\x20 copy Server \n'));
        gulp.src(['../Server/**', '!../Server/node_modules/**/*', '!../Server/README.md'])
            .pipe(gulp.dest('dist/data-front/Server'))
            .on('finish', function () {
                process.stdout.write(colors.blue('\x20\x20\x20 copy Server successfully!\n'));
                deferred.resolve(true);
            })
            .on('error', function () {
                process.stdout.write(colors.red('\x20\x20\x20 copy Server field!\n'));
                deferred.reject(new Error(error));
            });
        return deferred.promise;
    };

    // 第十六步 压缩Server下的js
    var sixteenthStep = function () {
        var deferred = Q.defer();
        process.stdout.write(colors.green('13)：Server -> \n'));
        process.stdout.write(colors.blue('\x20\x20\x20 minify js \n'));
        gulp.src('dist/data-front/Server/**/*.js')
            .pipe(uglify())
            .pipe(gulp.dest('dist/data-front/Server'))
            .on('finish', function () {
                process.stdout.write(colors.blue('\x20\x20\x20 minify Server successfully!\n'));
                deferred.resolve(true);
            })
            .on('error', function () {
                process.stdout.write(colors.red('\x20\x20\x20 minify Server field!\n'));
                deferred.reject(new Error(error));
            });
        return deferred.promise;
    };

    // 第十七步 打包zip
    var seventeenthStep = function () {
        var deferred = Q.defer();
        process.stdout.write(colors.green('14)：zip -> \n'));
        process.stdout.write(colors.blue('\x20\x20\x20 zip packing... \n'));
        gulp.src([
            'dist/**',
            '!dist/data-front/Client/doc/**/*',
            '!dist/data-front/Client/logs/**/*',
            '!dist/data-front/Client/README.md',
            '!dist/data-front/Client/bower_components/**/*',
            '!dist/data-front/Server/README.md',
            '!dist/data-front/Server/node_modules/**/*'
        ])
        .pipe(zip(zipfile))
        .pipe(gulp.dest('dist'))
        .on('finish', function () {
            process.stdout.write(colors.blue('\x20\x20\x20 zip packed successfully!\n'));
            // 觉得删除不好，保留
            // del('dist/data-front', {force: true}, function (error, stdout, stderr) {
            //     process.stdout.write(colors.blue('\x20\x20\x20 del data-front successfully!\n'));
            //     process.stdout.write(colors.green('\x20\x20\x20 BUILD SUCCESSFULLY!\n'));
            //     deferred.resolve(true);
            // });
            deferred.resolve(true);
            !!callback && callback({
                filepath: path.join(process.cwd(), '/dist/'+zipfile),
                filename: zipfile
            });
        })
        .on('error', function () {
            process.stdout.write(colors.red('\x20\x20\x20 zip packed field!\n'));
            deferred.reject(new Error(error));
        });
        return deferred.promise;
    };

    // 错误处理
    var error_catch = function (error) {
        process.stdout.write(colors.red('Field!\n'));
        process.stdout.write(colors.red(error.message));
    };

    // run
    Q.fcall(firstStep)
     .then(secondStep)
     .then(thirdStep)
     .then(forthStep)
     .then(fifthStep)
     .then(sixthStep)
     .then(seventhStep)
     .then(eighthStep)
     .then(ninthStep)
     .then(tenthStep)
     .then(eleventhStep)
     .then(twelvethStep)
     .then(thirteenthStep)
     .then(forteenthStep)
     .then(fifteenthStep)
     .then(sixteenthStep)
     .then(seventeenthStep)
     .catch(error_catch)
     .done();
}